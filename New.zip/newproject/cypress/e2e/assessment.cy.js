describe("assessment", () => {

 it('Testcase1: To find the Cursor is enabled in textbox', () => {
  cy.visit("https://www.webcargonet.com/qa-calc/")
cy.get(".result").type('1+2{enter}')
cy.get(".result").should('have.value', '1+2{enter}')

 })

    it('Testcase2: Validate CE option - Clear the Last entry', () => {
    cy.visit("https://www.webcargonet.com/qa-calc/")
       cy.xpath("//button[normalize-space()='1']").click()
       cy.xpath("//button[normalize-space()='2']").click()
       cy.xpath("//button[normalize-space()='3']").click()
       cy.xpath("//button[normalize-space()='4']").click()
        cy.xpath("//button[normalize-space()='CE']").click()
      
       cy.get(".result").should('have.value', '123')
        
            })
            it('Testcase3: (0) should return as 0', () => {
               cy.visit("https://www.webcargonet.com/qa-calc/")

               cy.xpath("//button[normalize-space()='(']").click()
               cy.xpath("//button[normalize-space()='0']").click()
               cy.xpath("//button[normalize-space()=')']").click()
            
                cy.xpath("//button[normalize-space()='=']").click()
              
               cy.get(".result").should('have.value', '0')
                
                    })

                    it('Testcase4: decimal point should allow only once', () => {
                      
          cy.visit("https://www.webcargonet.com/qa-calc/")
                      
                       cy.xpath("//button[normalize-space()='0']").click()
                     
                    
                        cy.xpath("//button[normalize-space()='.']").click()
                        
                       
                       cy.get(".result").should('have.value','0.')
                    }) 

                    it('Testcase5: click 0 and enter and able to see blank result instead of 0', () => {
                        cy.visit("https://www.webcargonet.com/qa-calc/")
                       cy.xpath("//button[normalize-space()='(']").click()

                        cy.xpath("//button[normalize-space()='0']").click()
                        cy.xpath("//button[normalize-space()=')']").click()
                        cy.get(".result").should('have.value','0')
                    })

})